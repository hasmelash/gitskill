import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
function NoteCounter(props){
   
        return (
                    <span className="badge badge-primary badge-pill">14</span>
        );
   
}
export default NoteCounter;